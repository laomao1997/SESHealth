# GoogleMapsMarker
Google Maps Marker is very useful when you want to show the location pin on Google Maps. It is possible to use image or icon or bitmap as Google Maps Marker Icon, even you can customize it by creating a layout for custom marker . If you want to play with Google Map Marker then this tutorial is for you. 

Tutorial Link : http://yasirameen.com/2017/09/understading-google-maps-marker/

WWW.YASIRAMEEN.COM
